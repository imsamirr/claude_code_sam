# Scrolling long-form video ads

**The format:** one looping background clip of the narrator's world. The full story scrolls up from the bottom in big bold outlined text, and a voice-over reads it word for word over a soft music bed. The video runs 4–5 minutes, and the Facebook caption is short.

## Studied examples (Atria, saved 2026-11)

| Ad | Length | Background | Text | Audio |
|---|---|---|---|---|
| Cat Care Corner (m1845460936626768), vet "pulled 40 senior cats", #1 of 122 in-account | 5:22 | vet in a clinic room | yellow, black outline | music/VO |
| FluffCo (m926031156988423), hotel front desk "What if I just steal one?" | 4:51 | hotel hallway, someone carrying a pillow | white, black outline | music only |
| Albert H. Benton (m1476614284352616), physical therapist on sciatica | 4:24 | PT treating a patient | white, black outline | voice-over reading the text |

**What they share:**
- **Frame:** 720×1280 at 30fps.
- **Opening:** the hook sits in the lower half at second 0, then scrolls at reading pace (about 2.3–2.5 words per second, about 650–750 words in total).
- **Text:** paragraphs of 1–3 short sentences, centered, about 86% of the frame width.
- **Caption:** 1–3 sentences (the hook plus curiosity). *2026-11-16: this applies to Mode A only. In Mode B (a re-cut static), the long runners use the full story as the primary text; see the market study section below.*

## Market study 2026-11-16: how long-running scroll videos are actually built

Source: `ads/brands/comfortwear/research/learning/market_study_2026-11-16.md`. Frames were pulled from the video files and checked.

| Ad | Run data | Length | Background | Audio | Pace |
|---|---|---|---|---|---|
| Herbal Health Findings / Estella, "wasn't really gout" (m3736136016541332) | **#1 of 551 at 106 days**; the same body ran as statics for 117–124 days | 469 s, 11.0k chars | a still of the ingredient (a black-garlic bowl), reused across stories | music only | about 4.0 words/s |
| Estella, profane gout story (m1665310724979818) | new on 11-15 | 1,133 s, 28.8k chars | the same garlic still | music only | about 4.5 words/s |
| American Health Support Community / Naturva, pulmonologist (m1130129209949753) | rank 1–2 of 133, reach up 140% in 7 days | 843 s, 21.9k chars | a still of the narrator's world (a lung-function test) | music only | about 4.3 words/s |
| Naturva, "My Wife Passed by Choking…" (older) | **188 days** as a video; the 17.1k static ran 197 days, and the video launched about 10 days after it | 795 s | n/a | n/a | n/a |
| Emma Livy / Bloomin, hysterectomy (m2200738350785208) | 43 days, now inactive; its static ran 47 days | 718 s | the hook object (a bruised belly) | music only | about 1.5 words/s (slow) |

**What this changes (evidence-based, not yet tested in our account):**
1. **Mode B, "proven-static re-cut," is the market's main scroll format.**
   - The full long-form body (11–29k chars, P.S. stack included) scrolls unchanged.
   - Every winner above re-cut a static that had already been running 1–4 weeks.
   - Our 600–720-word written-for-scroll script is now **Mode A**. Keep it, but test B against it.
2. **The pace is much faster than ours:** 4.0–4.5 words a second in the winners, against our 2.5. *(Softened 2026-11-23: two new music-only scrolls run at 2.5–2.8 words a second and rank 1/34 and 7/310. The working band is 2.5–4.5; see below.)* Nobody reads every word at that speed. The video works as a moving wall of text that signals "this is a real story", and the full text sits in the primary text too. The one slow example, 1.5 words a second, has retired. For Mode B, render with `python ads/scroll_video.py … --no-voice --px-per-frame 2` (added 2026-11-16). That's 120 px/s at 60 fps, still whole-pixel steps, about 4–4.5 words a second. The default of 1 px per frame (about 2.5 words a second) stays for Mode A.
3. **In Mode B, the primary text is the full story,** not a 1–3 sentence caption.
4. **Music only.** None of the scroll winners has a voice-over. Keep ElevenLabs voice for Mode A tests only.
5. **The background only has to be calm and on-topic.** The hook object is good (our rule), but Estella reaches #1 with one ingredient still reused across stories. A still of the narrator's world (Naturva) works too. For us, that means a still of the shoes in the story's setting is acceptable.
6. **Gap:** no footwear competitor runs scrolling-text videos. Orthora, Hike and Oobend run 300–600 s voice-over or 3D-cartoon story videos instead.

## Market study 2026-11-23: pace band, square format, and a "chapter one" mode

Source: `ads/brands/comfortwear/research/learning/market_study_2026-11-23.md`. Frames and audio were checked with ffmpeg.

| Ad | Run data | Format | Length | Background | Audio | Pace |
|---|---|---|---|---|---|---|
| Herbal Health Findings / Estella (m3736136016541332) | **#1 of 549 at 113 days**, still active | 9:16 | 469 s | ingredient still | music only | about 4.0 words/s |
| Naturva (m1130129209949753) | rank 2/131 at 21 days, active | 9:16 | 843 s | still of the narrator's world | music only | about 4.3 words/s |
| Susan Miller (m1662443618619314) | rank 1/34 at 6 days, rising | **720×720 square** | 1,035 s, the full 16.7k static body | blurred still (a man in a wheelchair); white condensed text with a dark outline | audio track present; the transcript failed | **2.8 words/s** |
| Ageless Beauty Secrets (m1543429487624419) | rank 7/310 at 4 days, rising | 9:16 | 538 s, 7.6k body | looping clip of the insider's dressing room | music only (empty transcript) | **2.5 words/s** |
| New World Publications fiction app (m1475300441229556 and 5+ duplicates) | ranks 1, 2, 3, 6 and 10 of 34 at 5 days | 9:16 | 222 s | "satisfying" ASMR slime clip, word-by-word captions | fast voice-over | about 3.6 words/s; the video covers only the first ~25% of the 18k story and stops at a cliffhanger |

**What this changes:**
1. **The Mode B pace band is 2.5–4.5 words a second.** The only long-run proof is still at 4–4.3 (Estella, Naturva). The slow pair is 4–6 days old. Test both ends on one body: `--px-per-frame 1` (about 2.5) against `--px-per-frame 2` (about 4).
2. **Square 1:1 is a live scroll format for feed placements.** `scroll_video.py` renders 1080×1920 only. For a 1:1 test, center-crop the finished file with `ffmpeg -i in.mp4 -vf "crop=1080:1080" -c:a copy out_1x1.mp4`. Then check that the hook is inside the crop at second 0: the 9:16 render starts the hook in the lower half, which a center crop can cut off. If it does, re-render with the hook starting higher.
3. **Mode C, "chapter one":** a voice-over reads the opening 20–25% of a proven LF body, up to its master loop, over a calm on-topic clip. The video ends on an explicit "the rest is in the caption", and the primary text carries the full story. It is cheaper than a full voiced scroll (about 600 words of ElevenLabs), so it fits the 5k-credit cap. Evidence so far is one advertiser's duplicates at days 1–5, so treat it as a test.
4. **Unchanged:** music-only for Mode B, the full story as the primary text, and a calm on-topic still. Every scroll in the table follows these.

## Pipeline: `ads/scroll_video.py`

```bash
python ads/scroll_video.py --brand <brand> --spec <variations.json> --only assets --tts openai [IDs]  # voices + Veo clips + tile sheets
# review every <ID>/bg_*_tiles.jpg; delete + re-run bad clips
python ads/scroll_video.py --brand <brand> --spec <variations.json> --music <bed.mp3> --only render [IDs]
```

### The spec (one object per variation)

| Field | What it holds |
|---|---|
| `id` | LV<nn> |
| `script` | Paragraphs separated by blank lines, 600–720 words |
| `voice` | Gender, age and accent notes for the narrator |
| `background` | Veo prompt for the narrator's world |
| `caption`, `headline`, `landing_page` | The ad's caption, headline and landing page |
| `offer_swaps`, `alt_hooks` | Dated offer replacements and alternate openings |
| `text_color` | Optional: white or yellow |

- **Spec fields:** `background_image` holds the photo prompt; ComfortWear's `background_image_prompt` is mapped to it. `"audio": "music"` or `"voice"`. ComfortWear's `"voiceover": true` maps to `"audio": "voice"`, and a spec with no `audio` field is **music-only** (voice is opt-in). `--no-voice` forces music-only. `el_voice_id`, or `el_voice` (a name: Rachel, Matilda, Aria, Jessica, Laura, Brian), picks the voice. The default comes from the narrator's age and gender.
### Still-image backgrounds, music-only and voice specs (both brands, shared script merged 2026-11-12)
- **`background_image`** (instead of `background`): a prompt for one calm, mid-to-dark 9:16 phone photo of the narrator's world. It's rendered with Kie `nano-banana-pro` at 2K, then given a slow breathing zoom over the whole video (no Veo). Keep the middle of the frame quiet, because white text sits on it.
- **`"audio": "music"`**: no voice-over. The text scrolls at a fixed reading pace (`MUSIC_WPS` = 2.5 words a second, with the hook held for 2.5 seconds) and the music bed plays at −6 dB. Write these scripts with shorter paragraphs and more one-line cliffhangers.
- **Quality (user feedback 2026-11-12: "blurry and a bit laggy"):**
  - **Resolution and encoding:** render at 1080×1920 at 60 fps, with the text layer laid out at full resolution (the font and sizes scale with the width), x264 `medium` at CRF 17.
  - **Motion:** music-only videos scroll by whole pixels: 1px every 3 frames during the 6-second ease-in, then exactly 1px per frame (60px/s). Fractional speeds make the text alternate 1px and 2px steps, which reads as stutter. The video's length follows from the text height.
  - **Background:** still-image backgrounds are static. ffmpeg `zoompan` moves in whole-pixel steps and jitters.
  - **Render time:** about 10–15 minutes per video on 4 cores.
- **Render speed fix (2026-11-19):** the final composite used to read the background and the tall text layer with `-loop 1 -i text.png`, so ffmpeg re-decoded and re-converted the ~1080×20,000 RGBA PNG on every frame (about 1 fps per render; 12 videos would have taken ~12 hours). Both stills are now decoded once and cached with the `loop` filter. Output frames are pixel-identical (checked) and the filter cost drops ~40× (3 s of video: 39 s → 0.9 s), so x264 is the only real cost. `SCROLL_X264_PRESET` (default `medium`) overrides the encoder preset if a deadline needs it.
- **ElevenLabs cost logging (2026-11-19):** the API key lacks `user_read`, so `GET /v1/user/subscription` returns 401. `tts_eleven` now appends each section's `character-cost` response header to `<ID>/el_costs.txt`; sum it for the real credits used. Turbo v2.5 billed about 0.22 credits per character on this account (900 credits for a 4,000-character script), well under the ledger's 0.5/char reservation.
- **Background must match the copy (same feedback):** the photo shows the story's hook object (the jelly jar with the teeth in it, the moldy case hinge, the check next to the denture), large in the upper half, with a darker, simpler lower half for the text. Never a generic setting. Check every background for burned-in text or captions and re-render any that have them.
- **Scroll speed (user feedback 2026-11-12):** the text must rise slowly from the first frame, like the references, never jump. Music-only videos scroll at one steady speed (story length ÷ runtime, about 35–40 px/s) after an ease-in at a third of that speed for the first 6 seconds. Voice videos stay at that steady speed until it reaches the voice's place, then follow the voice.
- **Music beds:** without `--music`, one Suno bed is generated per spec file (`<stem>_music.mp3` next to it) and shared by its variations. Set `music_prompt` on the first variation to change the mood.
- **ElevenLabs direct (2026-11-12):** the user added an ElevenLabs API key as the environment variable `ElevenLabKey`. Whenever it is set, `scroll_video.py` uses the ElevenLabs API directly first (`eleven_multilingual_v2`, Rachel for women and Brian for men, or `el_voice_id` in the spec), then falls back to Kie, then OpenAI. Use `--tts elevenlabs` to force it.
- **ElevenLabs credit cap (user rule 2026-11-12):** at most 5,000 ElevenLabs credits per run. The default model is `eleven_turbo_v2_5` at 0.5 credit per character, so a ~700-word script costs about 2,000 credits and at most 2 voice videos fit per run; every other video is music-only. `scroll_video.py` enforces this: each voice video reserves its credits in a per-day ledger (`elevenlabs_credit_ledger.json`, shared by parallel processes), and one that would go over `--voice-budget` (default 5000) is rendered music-only with an `audio_note`. Check the real usage with `GET https://api.elevenlabs.io/v1/user/subscription` (`character_count`) before and after.
- **Voice availability (2026-11-12):** Kie's ElevenLabs models (turbo-2-5 and multilingual-v2) returned "Internal Error", and the OpenAI fallback needs account credits. Check both before a voice batch.

### What each stage does

- **Voice:**
  - ElevenLabs via Kie (`elevenlabs/text-to-speech-turbo-2-5`) is the first choice. Both Kie ElevenLabs models returned "Internal Error" on 2026-11-11.
  - The fallback is OpenAI `gpt-4o-mini-tts` (voice `sage`, read as a real woman telling her own story) with `--tts openai`. Report which one was used (`<ID>/voice_engine.txt`).
  - The voice is generated in sections of about 110 words. Paragraph start times come from section durations split by word count. The text layer's y-position is piecewise linear, so each paragraph reaches the reading line (30% down) when the voice starts it.
- **Background:**
  - Kie `veo3_fast` makes 2 clips of 8 seconds from the **same prompt**, so they're two moments of one place. They're crossfaded, looped, darkened slightly, and Veo's own audio is dropped.
  - Never write "iPhone video" in the prompt, because Veo then draws a phone frame. Say "raw handheld footage… the camera itself is never visible". "A different angle" drifts to a different town.
- **Music:** one Suno V4_5 instrumental bed per angle (a soft piano or acoustic mood, no drums), mixed at −24 dB under the voice and faded out at the end.
- **Text:** Montserrat ExtraBold (`ads/assets/fonts`, OFL) at 46px with a 5px black stroke, white by default.

### QA, in this order

1. Tile sheets of every clip: no phone frame, no logos, no characters, the right setting. Also check:
   - **Letterbox bars:** Veo sometimes returns 9:16 with black bars baked in. Run `cropdetect` on every clip; when it isn't `720:1280:0:0`, crop to 9:16 inside the bars and scale back to 720×1280.
   - **Folded or bent geometry:** wide river and landscape scenes at 9:16 come back with the far bank bent up into a wall (LV01 failed this twice). Use an interior or close scene instead, or switch that video to a cheap-mode image.
   - **The background matches the final script:** when a story detail is changed (for example frozen peas to a foot tub), update the `background` prompt too and regenerate the clips.
2. Frames at 0.5s, 30s and 2 minutes, plus the last 10 seconds: the hook is visible at the start, the text is legible, and the CTA rests on screen at the end.
3. Duration matches the voice.
4. Spot-check that the voice is in sync with the text.

## Writing

Use the writer spec in `ads/brands/comfortwear/output/scroll_videos/scripts/WRITER_SPEC.md`. It's the long-form rules adapted for the ear:
- no symbols, and numbers written as they're spoken
- 600–720 words
- the hook is on screen at second 0
- the source ad's DNA is kept
- 3 variations per angle, each a different story and background
- the brand's dated close

**Names:** dedupe them across the batch (narrators, messengers and towns) and against existing LF files. Never reuse a competitor's signature detail (for example Orthora's frozen peas).

## Delivery
- **Notion:** one card per angle on the brand's board (Comfort Wear's is the "ComfortWear Video Board" database, data source `fc6096bb-…`), titled `LV01–03 | Scroll Video | <Angle>`. List the 3 variations on it, each with: story, headline, caption, the video, the full on-screen script, offer swaps and alternate hooks. Escape `$` as `\$` in the content, or Notion may read prices as math.
- **Video files (superseded, see HQ mode below):** do NOT put an 18MB re-compressed full-length video on a card. The user rejected that quality. The command below is kept only for short clips:
  ```bash
  ffmpeg -i LVxx.mp4 -c:v libx264 -preset veryfast -b:v 380k -maxrate 420k -bufsize 840k -c:a aac -b:a 64k -movflags +faststart notion/LVxx.mp4
  ```
  Call `notion-create-file-upload` with `content_type: "video/mp4"`, because the default `application/mp4` rejects a `video/mp4` POST. POST the file right away, and create the card within the hour. Embed it with `<video source="file-upload://<id>">LVxx video</video>`. For anything over 20MB, use Drive (`create_file` with a `sha256:<hash>:<path>` reference) and link to it.
- **Before the final render, fact-check the on-screen text:** city and state pairs, spacing inside quotes, prices that add up. A mistake means re-rendering the video.
- **Replacing videos:** `--replace <map.json>` (local path → existing Drive link or file id) overwrites a file's content in place, so its link and the Notion links stay the same.
- **Drive API uploader (2026-11-12):** `python ads/drive_upload.py --brand <brand> --folder-id <id> --names <map.json> <files>` (also accepts `--folder <id>` and `"<path>::<Drive name>"` arguments) uploads files of any size (resumable) and prints each Drive link. It needs `GDRIVE_CLIENT_ID`, `GDRIVE_CLIENT_SECRET` and `GDRIVE_REFRESH_TOKEN`, an OAuth refresh token for the Drive owner with the `drive` scope, set up through Google Cloud and the OAuth Playground. Use it instead of the Drive connector, which caps files at about 3 MB. The folder id and naming rule live in `brand.json → longform_program.scroll_videos`.

- **Sample:** send one video with SendUserFile.


## Still-image HQ mode (the default, user decision 2026-11-11: "the main purpose of the video is the text")

> **Implementation note (shared script merged 2026-11-12):** the shared `scroll_video.py` now renders at **1080×1920, 60 fps**: whole-pixel scroll (1 px per frame after a 6-second ease-in), a static background and x264 CRF 17. The 50 fps, blur and CRF 27 details below describe the earlier ComfortWear-only version. Delivery rules (Drive, hook previews, naming) still apply.

The user rejected the first renders as poor quality. Those were 720p Veo backgrounds compressed to 380 kbps to fit Notion. Every video now uses the following.

**Background.** One dedicated still photo per video from the spec's `background_image_prompt`, made with Kie nano-banana-pro at **2K, 9:16**. It's a moment from that story, in the iPhone-snapshot style. Never share one across videos. Check every photo for readable text (shirts, signs) and logos.

**Render** (`build_still` in `scroll_video.py`):
- 1080×1920, text at 1.5× the 720p sizes (69px Montserrat ExtraBold, 8px stroke)
- **exactly 1 px per frame at 50 fps** (50 px/s, about 2.2 words a second). Whole-pixel steps don't shimmer; fractional speeds are rounded and judder.
- the hook starts at 60% height and rises slowly; the CTA rests mid-screen for 3 seconds at the end
- a light `gblur=sigma=2` on the photo. Detailed textures behind moving text otherwise double the file size (390MB vs 155MB on cobblestones), and the text is the ad.
- x264 `-preset fast -crf 27 -maxrate 4500k`: crisp text at about 3–4.5 Mbps, so 5.5 minutes is about 120–180MB
- the text layer is padded by one screen above and below, and the visible 1080×1920 window is cropped from it each frame. Overlaying the full 16k-pixel layer is 2–3× slower. Each video takes about 4 minutes to render.

**Delivery.** Full files are 90–180MB, which is over Notion's 20MB limit and the Drive connector's 10MB limit, so they go up through the Drive API:
- **Full files go to Google Drive (user setup 2026-11-12):** `python ads/drive_upload.py --folder <brand.json longform_program.scroll_video_drive_folder> <files>` uploads each full-quality video with the Drive API: resumable, about 10–20 s per 100–180MB file. Credentials are env `GDRIVE_CLIENT_ID`, `GDRIVE_CLIENT_SECRET` and `GDRIVE_REFRESH_TOKEN` (the user's own OAuth app). It prints JSON lines with `id` and `link`. Name each file like its Notion concept: `<ID>.mp4::<ID> - <Concept title> - <Angle>.mp4` (the user asked for this on 2026-11-12). Re-uploading the same name updates that file in place, so links stay valid. On each Notion card, write `[Download <ID> from Google Drive](https://drive.google.com/file/d/<id>/view) · <size, length> · full quality`. Don't write the bare file name: Notion turns "LV01.mp4" into a broken link. If the Drive variables are missing or the upload fails, fall back to SendUserFile download cards in the chat and say so.
- on Notion, attach a **30-second full-quality hook preview** (`-t 30 -c:v copy`, about 15MB), plus that "Full video" note
- never put a re-compressed under-20MB full-length video on a card. That's what looked bad.
- existing video blocks can't be matched by `update_content`. To swap videos, rewrite the card with `replace_content`.

## Cheap mode (superseded by the HQ mode above)

- **Background:** one **dedicated** still image per video, made with Kie nano-banana-pro (about 15 credits) from the spec's `background_image_prompt`, then a slow zoom in and out on a 40-second seamless loop. This costs about 10× less than 2 Veo clips (about 130 credits, or about $0.70 per video).
- **Never reuse images.** Never share one image across concepts, and never reuse the concept's static images A–D. Every video gets its own scene, in the same iPhone-realism style.
- **Music:** the angle's bed from `ads/brands/<brand>/assets/music/<angle>.mp3` (Suno, made once). Mapping: europe, disney, plussize, nurse, over50.
- **Voice:** none while Kie ElevenLabs is failing (Internal Error on 2026-11-11). The scroll runs at reading pace, about 2.4 words per second (`--no-voice`).
- **File size:** rendered at 400 kbps, so a 5-minute video is about 19MB and can be attached directly to its Notion card.

```bash
python ads/scroll_video.py --brand <brand> --spec <scroll_specs.json> --music ads/brands/<brand>/assets/music/<angle>.mp3 --only render --no-voice <IDs>
```

**Kie balance:** check it first (`GET /api/v1/chat/credit`). A negative balance means every generation fails.

## Voice-over with ElevenLabs (user rules 2026-11-12: at most 5,000 credits per run, 1–2 voiced concepts)

- **Key:** env `ElevenLabKey` (direct ElevenLabs API, not Kie). It can't read the account or list voices, so the voice IDs are fixed in `EL_VOICES` (US voices: Rachel, Matilda, Aria, Jessica, Laura).
- **Opt in per video** with `"voiceover": true` in the spec. Pick the **1–2 concepts with the strongest hooks** for voice. Every other video stays music-only.
- **Voice choice:** `"el_voice": "<name>"`, or by default from the narrator's age in `"voice"`: 55+ gets Matilda, under 42 gets Jessica, everyone else Rachel.
- **Cost:** the model is `eleven_turbo_v2_5`, at 0.5 credit per character, so a 700-word script is about 2,000 credits.
- **Hard caps in the script:** 5,000 credits and 2 voiced videos per UTC day, tracked in `output/scroll_videos/elevenlabs_credit_ledger.json` (shared script; per brand, per day) across separate invocations. Override with `ELEVENLABS_RUN_BUDGET` / `ELEVENLABS_MAX_VOICED` only if the user raises the limit.
- **Over the cap:** the video falls back to music-only and the log says so. Report the credits used in the run summary.
- **Render:** the whole script is read in one request, so the narration flows naturally. Symbols are spoken naturally (HSA and FSA, percent). The text still moves exactly 1 px per frame, with the frame rate (24–60) chosen so the scroll lasts as long as the narration. The music bed plays at about −18 dB under the voice.
